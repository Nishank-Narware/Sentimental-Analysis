# sentimental-analysis

company:codtech it solutions

name :vartika Kushwaha

intern id :CT04DH759

domain:Machine learning

duration:4 weeks

This project implements a simple sentiment analysis pipeline using Python's scikit-learn. It classifies user reviews or text data into Positive or Negative sentiments using a combination of text preprocessing, TF-IDF vectorization, and a linear classifier (SGDClassifier with logistic regression loss).

output :

<img width="599" height="159" alt="image" src="https://github.com/user-attachments/assets/201500dc-3212-4ee4-b9ac-9a90ca1269a2" />
